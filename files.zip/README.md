# Project Title

This repository contains a project for calculating simple interest using a shell script.

## Features

- Calculate simple interest
- Easy to use

## Usage

To use the script, run the following command:

```sh
./simple-interest.sh